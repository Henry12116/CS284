public abstract class Shape implements Printable	
{
	//declares doubles area and perimeter
	public double perimeter;
	public double area;
}