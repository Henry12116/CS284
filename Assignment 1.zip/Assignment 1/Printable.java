public interface Printable
{
//prints parameters, area, and perimeter of shape
	public void shortPrint(); 

// prints the information in shortPrint in complete sentences
	public void longPrint();
}